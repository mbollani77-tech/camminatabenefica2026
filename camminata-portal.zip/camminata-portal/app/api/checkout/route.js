import Stripe from 'stripe';
import { getSupabaseAdmin } from '../../../lib/supabase';
import { getAmountForCategory } from '../../../lib/pricing';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function POST(request) {
  try {
    const body = await request.json();
    const { first_name, last_name, email, phone, category, payment_method } = body;

    if (!first_name || !last_name || !email || !category || !payment_method) {
      return Response.json({ error: 'Campi obbligatori mancanti' }, { status: 400 });
    }

    const amount = getAmountForCategory(category);
    const supabase = getSupabaseAdmin();

    // 1. Salva sempre l'iscrizione, stato iniziale "pending"
    const { data: participant, error: insertError } = await supabase
      .from('participants')
      .insert({
        first_name,
        last_name,
        email,
        phone,
        category,
        amount,
        payment_method,
        payment_status: 'pending',
      })
      .select()
      .single();

    if (insertError) throw insertError;

    // 2. Se paga in contanti, ci fermiamo qui: resta "pending" fino alla conferma a mano
    if (payment_method === 'cash') {
      return Response.json({ ok: true, participantId: participant.id });
    }

    // 3. Se paga con carta, creiamo la sessione Stripe Checkout
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      customer_email: email,
      line_items: [
        {
          price_data: {
            currency: 'eur',
            product_data: { name: `Camminata Benefica 20/09/2026 - ${category}` },
            unit_amount: Math.round(amount * 100),
          },
          quantity: 1,
        },
      ],
      success_url: `${process.env.NEXT_PUBLIC_BASE_URL}/success?method=card`,
      cancel_url: `${process.env.NEXT_PUBLIC_BASE_URL}/`,
      metadata: { participant_id: participant.id },
    });

    // Salviamo l'id sessione per collegarla al webhook di conferma
    await supabase
      .from('participants')
      .update({ stripe_session_id: session.id })
      .eq('id', participant.id);

    return Response.json({ ok: true, checkoutUrl: session.url });
  } catch (err) {
    console.error(err);
    return Response.json({ error: 'Errore interno, riprova più tardi' }, { status: 500 });
  }
}
