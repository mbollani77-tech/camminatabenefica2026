export default function Success({ searchParams }) {
  const isCash = searchParams?.method === 'cash';

  return (
    <main style={{ maxWidth: 480, margin: '0 auto', padding: '48px 20px', textAlign: 'center' }}>
      <h1 style={{ fontSize: 24 }}>Iscrizione confermata! 🎉</h1>
      <p style={{ fontWeight: 600, marginBottom: 4 }}>Domenica 20 settembre 2026</p>
      {isCash ? (
        <p style={{ color: '#57534e' }}>
          Ti aspettiamo il giorno dell'evento: ricordati di portare l'importo esatto in contanti
          per completare il pagamento al check-in.
        </p>
      ) : (
        <p style={{ color: '#57534e' }}>
          Il pagamento è andato a buon fine. Riceverai una email di conferma a breve.
        </p>
      )}
    </main>
  );
}
