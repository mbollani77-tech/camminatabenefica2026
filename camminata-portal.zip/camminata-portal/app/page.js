'use client';

import { useState } from 'react';

const CATEGORY_OPTIONS = [
  { value: 'adulto', label: 'Adulto', amount: 15.0 },
  { value: 'bambino', label: 'Bambino (fino a 12 anni)', amount: 5.0 },
  { value: 'senior', label: 'Senior (65+)', amount: 10.0 },
  { value: 'agevolata', label: 'Quota agevolata', amount: 5.0 },
];

export default function Home() {
  const [form, setForm] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    category: 'adulto',
    payment_method: 'card',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const selected = CATEGORY_OPTIONS.find((c) => c.value === form.category);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Errore durante l\'iscrizione');
      }

      if (form.payment_method === 'card' && data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
      } else {
        window.location.href = '/success?method=cash';
      }
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <main style={{ maxWidth: 480, margin: '0 auto', padding: '32px 20px' }}>
      <h1 style={{ fontSize: 24, marginBottom: 4 }}>Camminata Benefica</h1>
      <p style={{ color: '#57534e', marginBottom: 4 }}>Domenica 20 settembre 2026</p>
      <p style={{ color: '#57534e', marginBottom: 24 }}>Modulo di iscrizione</p>

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <input
          required
          placeholder="Nome"
          value={form.first_name}
          onChange={(e) => update('first_name', e.target.value)}
          style={inputStyle}
        />
        <input
          required
          placeholder="Cognome"
          value={form.last_name}
          onChange={(e) => update('last_name', e.target.value)}
          style={inputStyle}
        />
        <input
          required
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={(e) => update('email', e.target.value)}
          style={inputStyle}
        />
        <input
          placeholder="Telefono (opzionale)"
          value={form.phone}
          onChange={(e) => update('phone', e.target.value)}
          style={inputStyle}
        />

        <label style={labelStyle}>Categoria</label>
        <select
          value={form.category}
          onChange={(e) => update('category', e.target.value)}
          style={inputStyle}
        >
          {CATEGORY_OPTIONS.map((c) => (
            <option key={c.value} value={c.value}>
              {c.label} — €{c.amount.toFixed(2)}
            </option>
          ))}
        </select>

        <label style={labelStyle}>Metodo di pagamento</label>
        <div style={{ display: 'flex', gap: 16 }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <input
              type="radio"
              checked={form.payment_method === 'card'}
              onChange={() => update('payment_method', 'card')}
            />
            Carta (online ora)
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <input
              type="radio"
              checked={form.payment_method === 'cash'}
              onChange={() => update('payment_method', 'cash')}
            />
            Contanti (a inizio evento)
          </label>
        </div>

        <div style={{ background: '#fff', borderRadius: 8, padding: 12, fontWeight: 600 }}>
          Totale da pagare: €{selected.amount.toFixed(2)}
        </div>

        {error && <div style={{ color: '#b91c1c' }}>{error}</div>}

        <button type="submit" disabled={loading} style={buttonStyle}>
          {loading ? 'Attendere...' : form.payment_method === 'card' ? 'Vai al pagamento' : 'Conferma iscrizione'}
        </button>
      </form>
    </main>
  );
}

const inputStyle = {
  padding: '10px 12px',
  borderRadius: 8,
  border: '1px solid #d6d3d1',
  fontSize: 15,
};

const labelStyle = { fontSize: 13, color: '#57534e', marginBottom: -8 };

const buttonStyle = {
  padding: '12px 16px',
  borderRadius: 8,
  border: 'none',
  background: '#16a34a',
  color: '#fff',
  fontSize: 16,
  fontWeight: 600,
  cursor: 'pointer',
  marginTop: 8,
};
