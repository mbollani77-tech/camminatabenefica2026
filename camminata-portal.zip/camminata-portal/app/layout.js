export const metadata = {
  title: 'Camminata Benefica - Iscrizioni',
  description: 'Iscriviti alla camminata benefica del 20 settembre 2026',
};

export default function RootLayout({ children }) {
  return (
    <html lang="it">
      <body style={{ fontFamily: 'system-ui, sans-serif', margin: 0, background: '#f5f5f4' }}>
        {children}
      </body>
    </html>
  );
}
